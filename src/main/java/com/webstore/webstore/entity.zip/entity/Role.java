package com.webstore.webstore.entity;

public enum Role {
    USER, ADMIN
}